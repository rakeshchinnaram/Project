package com.team.lead.ControllerTest;

import com.team.lead.entity.Lead;
import com.team.lead.exception.LeadException;
import com.team.lead.service.TeamService;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import com.team.lead.controller.TeamController;

import java.text.ParseException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
public class LeadControllerTest {


    @Mock
    private TeamService teamService;

    @InjectMocks
    private TeamController teamController;

    @Test
    public void testLeadControlleraddLead() throws ParseException {

        Lead lead = createLeadObj();
        Mockito.when(teamService.getLeadByLeadId(lead.getLeadId())).thenReturn(false);
        ResponseEntity<?> responseEntity = teamController.createLead(lead);
        Mockito.verify(teamService,Mockito.times(1)).addTeamLeadDetails(lead);
        Assertions.assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    }

    @Test
    public void testLeadControllerWithExistingLeadId() throws ParseException {

        Lead lead = createLeadObj();
        Mockito.when(teamService.getLeadByLeadId(lead.getLeadId())).thenReturn(true);
        ResponseEntity<?> responseEntity = teamController.createLead(lead);
        Assertions.assertFalse(teamService.getLeadByLeadId(lead.getLeadId()));
        Mockito.verify(teamService,Mockito.times(0) ).addTeamLeadDetails(lead);
    }


    @Test
    public void testLeadControllerGetLead() throws ParseException, LeadException {

        String mobileNo="9845569878";
        Mockito.when(teamService.getTeamLeads(mobileNo)).thenReturn( List.of(createLeadObj()));
        ResponseEntity<?> responseEntity = teamController.getLeadDetails(mobileNo);
        Mockito.verify(teamService,Mockito.times(1)).getTeamLeads(mobileNo);
        Assertions.assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    }

   @Test
    public void throwExceptionForGetLead() throws ParseException, LeadException {

        String mobileNo="9845569878";
        Mockito.when(teamService.getTeamLeads(mobileNo)).thenThrow(new LeadException("No Lead found with the Mobile Number.","E10011"));
        ResponseEntity<?> responseEntity = teamController.getLeadDetails(mobileNo);
        Mockito.verify(teamService,Mockito.times(1)).getTeamLeads(mobileNo);
        assertThrows(LeadException.class,() -> teamService.getTeamLeads(mobileNo));
    }



    public Lead createLeadObj() throws ParseException {
        Lead lead = new Lead();
        lead.setLeadId(5668);
        lead.setEmail("rakesh@gmail.com");
        lead.setGender("Male");
        lead.setFirstName("Rakesh");
        lead.setLastName("Chinnaram");
        lead.setMobileNumber("9845569878");
        lead.setDob("05/12/2002");
        return lead;
    }

}
