package com.team.lead.ControllerTest;

import com.team.lead.entity.Lead;
import com.team.lead.exception.LeadException;
import com.team.lead.repository.TeamLeadRepository;
import com.team.lead.service.TeamService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.jpa.repository.support.SimpleJpaRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@SpringBootTest
public class LeadServiceTest {

    @Mock
    private TeamService teamService;

    @Mock
    TeamLeadRepository teamLeadRepository;


    @Test
    public void testLeadServiceaddLead() throws LeadException, ParseException {
        String mobileNo="9845569878";
        Lead lead = createLeadObj();
        when(teamService.getTeamLeads(mobileNo)).thenReturn((List.of(lead)));
        Assertions.assertEquals(lead.getLeadId(),5668);
    }


    @Test
    public void getLeadByIdPositivetest() throws ParseException {
        Optional<Lead> lead =Optional.of(createLeadObj());
        when(teamLeadRepository.findById(5668)).thenReturn(lead);
        Assertions.assertTrue(lead.isPresent());
    }

    @Test
    public void getLeadByIdNegetiveTest() throws ParseException {
        Lead lead = null;
        Optional  optional = Optional.ofNullable(lead);
        when(teamLeadRepository.findById(5668)).thenReturn(optional);
        Assertions.assertNull(optional.orElse(null));
    }

    public Lead createLeadObj() throws ParseException {
        Lead lead = new Lead();
        lead.setLeadId(5668);
        lead.setEmail("rakesh@gmail.com");
        lead.setGender("Male");
        lead.setFirstName("Rakesh");
        lead.setLastName("Chinnaram");
        lead.setMobileNumber("9845569878");
        lead.setDob("05/12/2002");
        return lead;
    }

}
