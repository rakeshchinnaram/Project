package com.team.lead.exception;

import java.util.Collections;
import java.util.List;

public class LeadException extends Exception{

    private String errorCode;
    private List<String> messages;

    public LeadException(String message,String errorCode)
    {
        this.messages = Collections.singletonList(message);
        this.errorCode= errorCode;
    }

    public String getErrorCode()
    {
        return errorCode;
    }
}
