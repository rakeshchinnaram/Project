package com.team.lead.service;

import com.team.lead.entity.Lead;
import com.team.lead.exception.LeadException;
import com.team.lead.repository.TeamLeadRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TeamServiceImpl implements TeamService{

    @Autowired
    TeamLeadRepository teamLeadRepository;


    @Override
    public List getTeamLeads(String mobileNumber) throws LeadException {

        List<Lead> leads =teamLeadRepository.findByMobileNumber(mobileNumber);
            if(leads.isEmpty())
            {
                throw new LeadException("No Lead found with the Mobile Number","E10011");
            }
        return leads;
    }

    @Override
    public boolean getLeadByLeadId(Integer leadId) {
        Optional<Lead> leadDetails= teamLeadRepository.findById(leadId);
        boolean flag = leadDetails.isPresent()?true:false;
        return flag;
    }

    @Override
    public void addTeamLeadDetails(Lead leadModel) {
        teamLeadRepository.save(leadModel);
    }


}
