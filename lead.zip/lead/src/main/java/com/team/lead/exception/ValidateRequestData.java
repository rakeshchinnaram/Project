package com.team.lead.exception;

import java.util.Collections;
import java.util.List;

public class ValidateRequestData extends Exception{

    private String errorCode;
    private List<String> messages;

    public ValidateRequestData(String message, String errorCode)
    {
        this.messages = Collections.singletonList(message);
        this.errorCode= errorCode;
    }
    public ValidateRequestData(List message, String errorCode)
    {
        this.messages = message;
        this.errorCode= errorCode;
    }


    public String getErrorCode()
    {
        return errorCode;
    }
}
