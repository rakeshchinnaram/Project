package com.team.lead;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LeadApplication {

	public static void main(String[] args) {
		System.out.println("Poster");
		SpringApplication.run(LeadApplication.class, args);
	}

}
