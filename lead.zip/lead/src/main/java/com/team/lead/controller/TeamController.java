package com.team.lead.controller;

import com.team.lead.entity.Lead;
import com.team.lead.exception.LeadException;
import com.team.lead.exception.ValidateRequestData;
import com.team.lead.model.LeadModel;
import com.team.lead.service.TeamService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@RestController
@Validated
public class TeamController {

    @Autowired
    TeamService teamService;

    @PostMapping("/lead/addLeads")
    public ResponseEntity<?> createLead(@Valid @RequestBody Lead leadModel)  {
        Map<String,Object> responseMap= new HashMap<>();
        ResponseEntity responseEntity =null;
        List<String> errorMessages = new ArrayList<>();

        if(leadModel.getLeadId() ==null || (!leadModel.getLeadId().toString().matches("\\d+")))
        {
            errorMessages.add("Lead id is null or not a Integer");
        }
        if ( leadModel.getFirstName()==null && leadModel.getFirstName().isBlank() || !leadModel.getFirstName().matches("[a-zA-Z]+"))
        {
            errorMessages.add("FirstName is Null or not in alphabets");
        }
        if(leadModel.getLastName()==null && leadModel.getLastName().isBlank() || !leadModel.getLastName().matches("[a-zA-Z]+")){
            errorMessages.add("LastName is Null or not in alphabets");
        }
        if(leadModel.getMiddleName()!=null && !leadModel.getMiddleName().isBlank() && !leadModel.getMiddleName().matches("[a-zA-Z]+")){
            errorMessages.add("MiddleName not in alphabets");
        }
        if(leadModel.getMobileNumber()==null && leadModel.getMobileNumber().isBlank()  ||  (leadModel.getMobileNumber().trim().length()<10 && !leadModel.getMobileNumber().matches("[6-9][0-9]{9}"))){
            errorMessages.add("MobileNumber is null or not a Integer");
        }
        if(leadModel.getGender()==null && leadModel.getGender().isBlank()  || !leadModel.getGender().matches("(?i)Male|Female|Others"))
        {
            errorMessages.add("Gender is Null or not in Male|Female|Others");
        }
        if (leadModel.getEmail()!=null && !leadModel.getEmail().isBlank()) {
            String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
            Pattern pattern = Pattern.compile(emailRegex);
            Matcher matcher = pattern.matcher(leadModel.getEmail());
            if(!matcher.matches())
            {
                errorMessages.add("EmailId is wrong format.");
            }
        }
        else{
            errorMessages.add("EmailId is null.");
        }
        Date dateOfBirth =leadModel.getDob();
        if(dateOfBirth==null){
            errorMessages.add("Date is Mandatory");
        }
        if(dateOfBirth!=null) {
            Date currentDate = new Date();
            if ( currentDate.before(dateOfBirth)) {
                errorMessages.add("The Date provided is in future.");
            }
        }

        if(errorMessages.size()>0)
        {
            responseMap.put("code","E10012");
            ResponseEntity<String> response = errorResponse(errorMessages,responseMap);;
            return response;
        }

        if(!teamService.getLeadByLeadId(leadModel.getLeadId()))
        {
            teamService.addTeamLeadDetails(leadModel);
            responseMap.put("status","Success");
            responseMap.put("data","Created Leads Successfully");
            responseEntity = new ResponseEntity<>(responseMap,HttpStatus.OK);
        }
        else {
            responseMap.put("code","E10010");
            errorMessages.add("Lead Already Exists in the database with the lead id");
            responseEntity=errorResponse(errorMessages,responseMap);
        }
        return responseEntity;
    }

    public ResponseEntity errorResponse(List<String> errorMessages,Map<String,Object> errorData)
    {
        Map<String,Object> validData= new HashMap<>();
        validData.put("status","error");
        errorData.put("Messages",errorMessages);
        validData.put("errorResponse",errorData);
        ResponseEntity<String> response =new ResponseEntity(validData,HttpStatus.BAD_REQUEST);
        return response;
    }


    @GetMapping("/lead/getLead")
    public ResponseEntity getLeadDetails(@RequestParam("mobileNumber") String mobileNumber)
    {
        List<String> errorMessage=new ArrayList<>();
        ResponseEntity<String> response = null;
        Map<String,Object> responseMap = new HashMap<>();
        List<Lead> leadDetails =null;
        try {
            String mobileNumberPattern = "^[6-9]\\d{9}$";
            if(StringUtils.hasText(mobileNumber) && mobileNumber.matches(mobileNumberPattern)) {
                leadDetails = teamService.getTeamLeads(mobileNumber);
                responseMap.put("status","success");
                responseMap.put("data",leadDetails);
                response= new ResponseEntity(responseMap,HttpStatus.OK);
            }
            else{
                Map<String,Object> errorData = new HashMap<>();
                errorData.put("errorCode","E10012");
                errorMessage.add("Mobile no is not Valid.");
                response =errorResponse(errorMessage,errorData);
            }
        }
        catch (LeadException leadException)
        {
            Map<String,Object> errorData = new HashMap<>();
            errorData.put("errorCode","E10011");
            errorMessage.add("No Lead found with the Mobile Number.");
            response =errorResponse(errorMessage,errorData);
        }
        return response;
    }


}
