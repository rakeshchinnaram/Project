package com.team.lead.repository;

import com.team.lead.entity.Lead;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TeamLeadRepository extends JpaRepository<Lead, Integer> {

    @Query("select l from Lead l where l.mobileNumber=:mobileNumber")
    List<Lead> findByMobileNumber(String mobileNumber);
}
