package com.team.lead.service;

import com.team.lead.entity.Lead;
import com.team.lead.exception.LeadException;

import java.util.List;

public interface TeamService {
    List<Lead> getTeamLeads( String mobileNumber) throws LeadException;

    boolean getLeadByLeadId(Integer leadId);

    void addTeamLeadDetails(Lead leadModel);
}
